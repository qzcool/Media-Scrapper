package com.u91porn.ui.porn91video.search;

/**
 * @author flymegoc
 * @date 2018/1/7
 */

public interface ISearch {
    void searchVideos(String searchId, String sort,boolean pullToRefresh);
}
