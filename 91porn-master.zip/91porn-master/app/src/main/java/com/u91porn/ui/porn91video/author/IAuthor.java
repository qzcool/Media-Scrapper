package com.u91porn.ui.porn91video.author;

/**
 * @author flymegoc
 * @date 2018/1/8
 */

public interface IAuthor {
    void authorVideos(String uid,boolean pullToRefresh);
}
