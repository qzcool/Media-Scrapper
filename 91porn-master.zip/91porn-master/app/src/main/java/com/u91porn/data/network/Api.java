package com.u91porn.data.network;

/**
 * @author flymegoc
 * @date 2018/1/17
 */

public interface Api {
    String APP_GITHUB_DOMAIN = "https://github.com/";
    String APP_MEIZITU_DOMAIN = "http://www.mzitu.com/";
    String APP_99_MM_DOMAIN = "http://www.99mm.me/";
    String APP_PROXY_XICI_DAILI_DOMAIN = "http://www.xicidaili.com/";

    String GITHUB_DOMAIN_NAME = "github";
    String PORN91_VIDEO_DOMAIN_NAME = "porn91_video_domain_name";
    String PORN91_FORUM_DOMAIN_NAME = "porn91_forum_domain_name";
    String PIGAV_DOMAIN_NAME = "pigav_domain_name";
    String MEI_ZI_TU_DOMAIN_NAME = "mei_zi_tu_domain_name";
    String MM_99_DOMAIN_NAME = "mm_99_domain_name";
    String GUO_BAN_JIA_DOMAIN_NAME = "guo_ban_jia_domain_name";
    String XICI_DAILI_DOMAIN_NAME="xici_daili_domain_name";
}
