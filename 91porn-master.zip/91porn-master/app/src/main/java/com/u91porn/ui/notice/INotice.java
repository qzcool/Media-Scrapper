package com.u91porn.ui.notice;

/**
 *
 * @author flymegoc
 * @date 2018/1/26
 */

public interface INotice extends IBaseNotice {
}
