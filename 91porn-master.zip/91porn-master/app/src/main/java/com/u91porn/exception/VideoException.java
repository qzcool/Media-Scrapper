package com.u91porn.exception;

/**
 * @author flymegoc
 * @date 2018/1/1
 */

public class VideoException extends Exception {

    public VideoException(String message) {
        super(message);
    }
}
