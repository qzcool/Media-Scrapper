package com.u91porn.ui.main;

import com.u91porn.ui.notice.NoticeView;

/**
 *
 * @author flymegoc
 * @date 2017/12/23
 */

public interface MainView extends NoticeView {
}
