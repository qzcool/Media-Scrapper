package com.u91porn.data;

import com.u91porn.data.db.DbHelper;
import com.u91porn.data.network.ApiHelper;
import com.u91porn.data.prefs.PreferencesHelper;

/**
 * @author flymegoc
 * @date 2018/3/4
 */

public interface DataManager extends DbHelper,ApiHelper,PreferencesHelper {

}
