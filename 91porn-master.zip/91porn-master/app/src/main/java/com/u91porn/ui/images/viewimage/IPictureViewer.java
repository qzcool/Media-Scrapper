package com.u91porn.ui.images.viewimage;

/**
 *
 * @author flymegoc
 * @date 2018/1/26
 */

public interface IPictureViewer {
    void listMeZiPicture(int id,boolean pullToRefresh);
    void list99MmPicture(int id,String imageUrl,boolean pullToRefresh);
}
