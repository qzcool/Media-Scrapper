package com.u91porn.ui.pigav.playpigav;

/**
 * @author flymegoc
 * @date 2018/1/30
 */

public interface IPlayPigAv {
    void parseVideoUrl(String url, String pId, boolean pullToRefresh);
}
