package com.u91porn.ui.images.mm99;

/**
 * @author flymegoc
 * @date 2018/2/1
 */

public interface IMm99 {
    void loadData(String category,boolean pullToRefresh, boolean cleanCache);
}
