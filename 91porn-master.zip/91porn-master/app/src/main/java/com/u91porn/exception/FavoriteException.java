package com.u91porn.exception;

/**
 * @author flymegoc
 * @date 2018/1/10
 */

public class FavoriteException extends Exception {
    public FavoriteException(String message) {
        super(message);
    }
}
