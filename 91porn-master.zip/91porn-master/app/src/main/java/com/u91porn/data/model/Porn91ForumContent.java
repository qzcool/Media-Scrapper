package com.u91porn.data.model;

import java.util.List;

/**
 * @author flymegoc
 * @date 2018/1/24
 */

public class Porn91ForumContent {
    private String content;
    private List<String> imageList;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public List<String> getImageList() {
        return imageList;
    }

    public void setImageList(List<String> imageList) {
        this.imageList = imageList;
    }
}
