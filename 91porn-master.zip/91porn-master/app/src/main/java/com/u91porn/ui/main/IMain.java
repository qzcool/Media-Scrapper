package com.u91porn.ui.main;

import com.u91porn.ui.notice.IBaseNotice;

/**
 *
 * @author flymegoc
 * @date 2017/12/23
 */

public interface IMain extends IBaseNotice {
}
