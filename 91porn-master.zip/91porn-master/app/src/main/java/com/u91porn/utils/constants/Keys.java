package com.u91porn.utils.constants;

/**
 * @author flymegoc
 * @date 2017/11/19
 * @describe
 */

public class Keys {

    public final static String KEY_INTENT_LOGIN_FOR_ACTION = "key_intent_login_for_action";
    public final static String KEY_INTENT_99_MM_ITEM = "key_intent_99_mm_item";
    public final static String KEY_INTENT_UNLIMIT91PORNITEM = "key_intent_unlimit91pornitem";
    public final static String KEY_INTENT_PIG_AV_ITEM = "key_intent_pig_av_item";
    public final static String KEY_INTENT_UID = "key_intent_uid";
    public final static String KEY_INTENT_BROWSE_FORUM_91_PORN_ITEM = "key_intent_browse_forum_91_porn_item";
    public final static String KEY_INTENT_PICTURE_VIEWER_IMAGE_ARRAY_LIST = "key_intent_picture_viewer_image_array_list";
    public final static String KEY_INTENT_PICTURE_VIEWER_CURRENT_IMAGE_POSITION = "key_intent_picture_viewer_current_image_position";
    public final static String KEY_INTENT_MEI_ZI_TU_CONTENT_ID = "key_intent_mei_zi_tu_content_id";

    public final static String KEY_SELECT_INDEX = "key_select_index";
}
