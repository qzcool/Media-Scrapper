package com.u91porn.ui.images.viewimage;

import com.u91porn.ui.BaseView;

import java.util.List;

/**
 * @author flymegoc
 * @date 2018/1/26
 */

public interface PictureViewerView extends BaseView {
    void setData(List<String> imageList);
}
