package com.u91porn.ui.about;

import com.u91porn.ui.update.IBaseUpdate;

/**
 *
 * @author flymegoc
 * @date 2017/12/23
 */

public interface IBaseAbout extends IBaseUpdate{
}
