package com.u91porn.ui.porn91forum.browse91porn;

import com.u91porn.data.model.Porn91ForumContent;
import com.u91porn.ui.BaseView;

/**
 *
 * @author flymegoc
 * @date 2018/1/24
 */

public interface Browse91View extends BaseView{
    void loadContentSuccess(Porn91ForumContent porn91ForumContent);
}
