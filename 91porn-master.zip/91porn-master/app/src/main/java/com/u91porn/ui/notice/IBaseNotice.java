package com.u91porn.ui.notice;

import com.u91porn.ui.update.IBaseUpdate;

/**
 *
 * @author flymegoc
 * @date 2018/1/26
 */

public interface IBaseNotice extends IBaseUpdate{
    void checkNewNotice(int versionCode);
}
