package com.u91porn.ui.images.meizitu;

/**
 * @author flymegoc
 * @date 2018/1/25
 */

public interface IMeiZiTu {
    void listMeiZi(String tag, boolean pullToRefresh);
}
