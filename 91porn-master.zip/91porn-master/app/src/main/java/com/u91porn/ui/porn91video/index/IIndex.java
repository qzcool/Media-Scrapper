package com.u91porn.ui.porn91video.index;

/**
 * @author flymegoc
 * @date 2017/11/27
 * @describe
 */

public interface IIndex {
    void loadIndexData(final boolean pullToRefresh, boolean cleanCache);
}
