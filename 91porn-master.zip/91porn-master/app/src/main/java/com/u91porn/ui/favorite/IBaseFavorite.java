package com.u91porn.ui.favorite;

/**
 * @author flymegoc
 * @date 2017/11/27
 * @describe
 */

public interface IBaseFavorite {
    void favorite(String uId, String videoId, String ownnerId);
}
