package com.u91porn.ui.porn91video.play;

import com.u91porn.ui.download.IBaseDownload;

/**
 * @author flymegoc
 * @date 2017/11/27
 * @describe
 */

public interface IBasePlay extends IBaseDownload{
}
