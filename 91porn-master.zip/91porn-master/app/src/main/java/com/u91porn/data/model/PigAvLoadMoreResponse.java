package com.u91porn.data.model;

/**
 *
 * @author flymegoc
 * @date 2018/2/1
 */

public class PigAvLoadMoreResponse {

    /**
     * td_data :

     <div class="td-block-row">

     <div class="td-block-span4">

     <div class="td_module_mx4 td_module_wrap td-animation-stack td-meta-info-hide">
     <div class="td-module-image">
     <div class="td-module-thumb"><a href="https://pigav.com/216713/%e9%a8%99%e5%a7%a6%e5%87%8c%e8%be%b1-%e9%a6%99%e4%b9%83-2.html" rel="bookmark" title="騙姦凌辱 香乃"><img width="300" height="194" class="entry-thumb" src="https://img.pigav.com/2017/12/qqq107-300x194.jpg" srcset="https://img.pigav.com/2017/12/qqq107-300x194.jpg 300w, https://img.pigav.com/2017/12/qqq107-341x220.jpg 341w" sizes="(max-width: 300px) 100vw, 300px" alt="" title="騙姦凌辱 香乃"/><span class="td-pigAvVideoUrl-play-ico"><img width="40" height="40" class="td-retina" src="https://pigav.com/wp-content/themes/Newsmag/images/icons/ico-video-large.png" alt="pigAvVideoUrl"/></span></a></div>                            </div>

     <h3 class="entry-title td-module-title"><a href="https://pigav.com/216713/%e9%a8%99%e5%a7%a6%e5%87%8c%e8%be%b1-%e9%a6%99%e4%b9%83-2.html" rel="bookmark" title="騙姦凌辱 香乃">騙姦凌辱 香乃</a></h3>
     <div class="meta-info">
     </div>


     </div>


     </div> <!-- ./td-block-span4 -->

     <div class="td-block-span4">

     <div class="td_module_mx4 td_module_wrap td-animation-stack td-meta-info-hide">
     <div class="td-module-image">
     <div class="td-module-thumb"><a href="https://pigav.com/100507/%e8%bb%8a%e9%9c%87%e6%ba%96%e5%82%99%e9%96%8b%e5%a7%8b-2.html" rel="bookmark" title="車震準備開始"><img width="300" height="194" class="entry-thumb" src="https://img.pigav.com/2016/04/163513tao1so0ilae8zuqs-300x194.jpg" srcset="https://img.pigav.com/2016/04/163513tao1so0ilae8zuqs-300x194.jpg 300w, https://img.pigav.com/2016/04/163513tao1so0ilae8zuqs-341x220.jpg 341w" sizes="(max-width: 300px) 100vw, 300px" alt="" title="車震準備開始"/><span class="td-pigAvVideoUrl-play-ico"><img width="40" height="40" class="td-retina" src="https://pigav.com/wp-content/themes/Newsmag/images/icons/ico-video-large.png" alt="pigAvVideoUrl"/></span></a></div>                            </div>

     <h3 class="entry-title td-module-title"><a href="https://pigav.com/100507/%e8%bb%8a%e9%9c%87%e6%ba%96%e5%82%99%e9%96%8b%e5%a7%8b-2.html" rel="bookmark" title="車震準備開始">車震準備開始</a></h3>
     <div class="meta-info">
     </div>


     </div>


     </div> <!-- ./td-block-span4 -->

     <div class="td-block-span4">

     <div class="td_module_mx4 td_module_wrap td-animation-stack td-meta-info-hide">
     <div class="td-module-image">
     <div class="td-module-thumb"><a href="https://pigav.com/216492/%e6%88%91%e7%9a%84%e7%b9%bc%e5%a7%8a%e6%98%af%e6%b3%a2%e5%a4%9a%e9%87%8e%e7%b5%90%e8%a1%a3.html" rel="bookmark" title="我的繼姊是波多野結衣"><img width="300" height="194" class="entry-thumb" src="https://img.pigav.com/2017/12/BBB069-300x194.jpg" srcset="https://img.pigav.com/2017/12/BBB069-300x194.jpg 300w, https://img.pigav.com/2017/12/BBB069-341x220.jpg 341w" sizes="(max-width: 300px) 100vw, 300px" alt="" title="我的繼姊是波多野結衣"/><span class="td-pigAvVideoUrl-play-ico"><img width="40" height="40" class="td-retina" src="https://pigav.com/wp-content/themes/Newsmag/images/icons/ico-video-large.png" alt="pigAvVideoUrl"/></span></a></div>                            </div>

     <h3 class="entry-title td-module-title"><a href="https://pigav.com/216492/%e6%88%91%e7%9a%84%e7%b9%bc%e5%a7%8a%e6%98%af%e6%b3%a2%e5%a4%9a%e9%87%8e%e7%b5%90%e8%a1%a3.html" rel="bookmark" title="我的繼姊是波多野結衣">我的繼姊是波多野結衣</a></h3>
     <div class="meta-info">
     </div>


     </div>


     </div> <!-- ./td-block-span4 -->

     <div class="td-block-span4">

     <div class="td_module_mx4 td_module_wrap td-animation-stack td-meta-info-hide">
     <div class="td-module-image">
     <div class="td-module-thumb"><a href="https://pigav.com/195399/%e3%81%93%e3%82%8c%e3%81%af%e3%80%81%e9%9d%9e%e5%b8%b8%e3%81%ab%e6%b4%bb%e7%99%ba%e3%81%ab%e8%89%af%e3%81%84%e3%81%a7%e3%81%99.html" rel="bookmark" title="これは、非常に活発に良いです"><img width="300" height="194" class="entry-thumb" src="https://img.pigav.com/2017/03/95ds5-300x194.jpg" srcset="https://img.pigav.com/2017/03/95ds5-300x194.jpg 300w, https://img.pigav.com/2017/03/95ds5-341x220.jpg 341w" sizes="(max-width: 300px) 100vw, 300px" alt="" title="これは、非常に活発に良いです"/><span class="td-pigAvVideoUrl-play-ico"><img width="40" height="40" class="td-retina" src="https://pigav.com/wp-content/themes/Newsmag/images/icons/ico-video-large.png" alt="pigAvVideoUrl"/></span></a></div>                            </div>

     <h3 class="entry-title td-module-title"><a href="https://pigav.com/195399/%e3%81%93%e3%82%8c%e3%81%af%e3%80%81%e9%9d%9e%e5%b8%b8%e3%81%ab%e6%b4%bb%e7%99%ba%e3%81%ab%e8%89%af%e3%81%84%e3%81%a7%e3%81%99.html" rel="bookmark" title="これは、非常に活発に良いです">これは、非常に活発に良い...</a></h3>
     <div class="meta-info">
     </div>


     </div>


     </div> <!-- ./td-block-span4 -->

     <div class="td-block-span4">

     <div class="td_module_mx4 td_module_wrap td-animation-stack td-meta-info-hide">
     <div class="td-module-image">
     <div class="td-module-thumb"><a href="https://pigav.com/218983/%e6%b8%a1%e8%be%ba%e7%be%8e%e7%be%bd%e4%bb%96%e4%ba%ba%e5%a6%bb%e5%91%b3%ef%bd%9e%e5%b7%a8%e4%b9%b3%e7%86%9f%e5%a5%b3.html" rel="bookmark" title="渡辺美羽他人妻味～巨乳熟女"><img width="300" height="194" class="entry-thumb" src="https://img.pigav.com/2018/01/z2w_b-300x194.jpg" srcset="https://img.pigav.com/2018/01/z2w_b-300x194.jpg 300w, https://img.pigav.com/2018/01/z2w_b-341x220.jpg 341w" sizes="(max-width: 300px) 100vw, 300px" alt="" title="渡辺美羽他人妻味～巨乳熟女"/><span class="td-pigAvVideoUrl-play-ico"><img width="40" height="40" class="td-retina" src="https://pigav.com/wp-content/themes/Newsmag/images/icons/ico-video-large.png" alt="pigAvVideoUrl"/></span></a></div>                            </div>

     <h3 class="entry-title td-module-title"><a href="https://pigav.com/218983/%e6%b8%a1%e8%be%ba%e7%be%8e%e7%be%bd%e4%bb%96%e4%ba%ba%e5%a6%bb%e5%91%b3%ef%bd%9e%e5%b7%a8%e4%b9%b3%e7%86%9f%e5%a5%b3.html" rel="bookmark" title="渡辺美羽他人妻味～巨乳熟女">渡辺美羽他人妻味～巨乳熟...</a></h3>
     <div class="meta-info">
     </div>


     </div>


     </div> <!-- ./td-block-span4 --></div><!--./row-fluid-->

     <div class="td-block-row">

     <div class="td-block-span4">

     <div class="td_module_mx4 td_module_wrap td-animation-stack td-meta-info-hide">
     <div class="td-module-image">
     <div class="td-module-thumb"><a href="https://pigav.com/216615/%e4%bd%a2%e5%ae%b6%e5%a7%90%e5%b7%a8%e4%b9%b3%e4%b8%ad%e5%87%baok%e6%a3%ae%e6%9e%97%e8%af%b1%e6%83%91%e6%88%91.html" rel="bookmark" title="佢家姐巨乳中出OK森林诱惑我"><img width="300" height="194" class="entry-thumb" src="https://img.pigav.com/2017/12/zzz720-300x194.jpg" srcset="https://img.pigav.com/2017/12/zzz720-300x194.jpg 300w, https://img.pigav.com/2017/12/zzz720-341x220.jpg 341w" sizes="(max-width: 300px) 100vw, 300px" alt="" title="佢家姐巨乳中出OK森林诱惑我"/><span class="td-pigAvVideoUrl-play-ico"><img width="40" height="40" class="td-retina" src="https://pigav.com/wp-content/themes/Newsmag/images/icons/ico-video-large.png" alt="pigAvVideoUrl"/></span></a></div>                            </div>

     <h3 class="entry-title td-module-title"><a href="https://pigav.com/216615/%e4%bd%a2%e5%ae%b6%e5%a7%90%e5%b7%a8%e4%b9%b3%e4%b8%ad%e5%87%baok%e6%a3%ae%e6%9e%97%e8%af%b1%e6%83%91%e6%88%91.html" rel="bookmark" title="佢家姐巨乳中出OK森林诱惑我">佢家姐巨乳中出OK森林诱...</a></h3>
     <div class="meta-info">
     </div>


     </div>


     </div> <!-- ./td-block-span4 -->

     <div class="td-block-span4">

     <div class="td_module_mx4 td_module_wrap td-animation-stack td-meta-info-hide">
     <div class="td-module-image">
     <div class="td-module-thumb"><a href="https://pigav.com/207504/%e5%90%8c%e4%b8%80%e6%97%a5%e7%94%9f%e6%9a%b4%e7%94%b7%e5%ad%904%e4%ba%ba%e4%b8%ad%e5%87%ba%e7%95%80%e5%bc%ba%e5%a5%b8%e5%98%85%e4%ba%ba%e5%a6%bb%e9%bb%91%e6%9c%a8.html" rel="bookmark" title="同一日生暴男子4人中出畀强奸嘅人妻黑木"><img width="300" height="194" class="entry-thumb" src="https://img.pigav.com/2017/08/kkk998-300x194.jpg" srcset="https://img.pigav.com/2017/08/kkk998-300x194.jpg 300w, https://img.pigav.com/2017/08/kkk998-341x220.jpg 341w" sizes="(max-width: 300px) 100vw, 300px" alt="" title="同一日生暴男子4人中出畀强奸嘅人妻黑木"/><span class="td-pigAvVideoUrl-play-ico"><img width="40" height="40" class="td-retina" src="https://pigav.com/wp-content/themes/Newsmag/images/icons/ico-video-large.png" alt="pigAvVideoUrl"/></span></a></div>                            </div>

     <h3 class="entry-title td-module-title"><a href="https://pigav.com/207504/%e5%90%8c%e4%b8%80%e6%97%a5%e7%94%9f%e6%9a%b4%e7%94%b7%e5%ad%904%e4%ba%ba%e4%b8%ad%e5%87%ba%e7%95%80%e5%bc%ba%e5%a5%b8%e5%98%85%e4%ba%ba%e5%a6%bb%e9%bb%91%e6%9c%a8.html" rel="bookmark" title="同一日生暴男子4人中出畀强奸嘅人妻黑木">同一日生暴男子4人中出畀...</a></h3>
     <div class="meta-info">
     </div>


     </div>


     </div> <!-- ./td-block-span4 -->

     <div class="td-block-span4">

     <div class="td_module_mx4 td_module_wrap td-animation-stack td-meta-info-hide">
     <div class="td-module-image">
     <div class="td-module-thumb"><a href="https://pigav.com/97916/%eb%82%98%eb%8a%94-%eb%b6%88%ec%be%8c%ed%95%9c-%ec%97%b0%ea%b8%b0-%eb%b2%84%ec%8a%a4%ed%8a%b8.html" rel="bookmark" title="나는 불쾌한 연기 버스트"><img width="300" height="194" class="entry-thumb" src="https://img.pigav.com/2016/03/v6hgfrs545-300x194.jpg" srcset="https://img.pigav.com/2016/03/v6hgfrs545-300x194.jpg 300w, https://img.pigav.com/2016/03/v6hgfrs545-341x220.jpg 341w" sizes="(max-width: 300px) 100vw, 300px" alt="" title="나는 불쾌한 연기 버스트"/><span class="td-pigAvVideoUrl-play-ico"><img width="40" height="40" class="td-retina" src="https://pigav.com/wp-content/themes/Newsmag/images/icons/ico-video-large.png" alt="pigAvVideoUrl"/></span></a></div>                            </div>

     <h3 class="entry-title td-module-title"><a href="https://pigav.com/97916/%eb%82%98%eb%8a%94-%eb%b6%88%ec%be%8c%ed%95%9c-%ec%97%b0%ea%b8%b0-%eb%b2%84%ec%8a%a4%ed%8a%b8.html" rel="bookmark" title="나는 불쾌한 연기 버스트">나는 불쾌한 연기 버스...</a></h3>
     <div class="meta-info">
     </div>


     </div>


     </div> <!-- ./td-block-span4 -->

     <div class="td-block-span4">

     <div class="td_module_mx4 td_module_wrap td-animation-stack td-meta-info-hide">
     <div class="td-module-image">
     <div class="td-module-thumb"><a href="https://pigav.com/215144/%e5%88%b6%e6%9c%8d%e4%b8%ad%e5%98%85c.html" rel="bookmark" title="制服中嘅C."><img width="300" height="194" class="entry-thumb" src="https://img.pigav.com/2017/11/rrr809-300x194.jpg" srcset="https://img.pigav.com/2017/11/rrr809-300x194.jpg 300w, https://img.pigav.com/2017/11/rrr809-341x220.jpg 341w" sizes="(max-width: 300px) 100vw, 300px" alt="" title="制服中嘅C."/><span class="td-pigAvVideoUrl-play-ico"><img width="40" height="40" class="td-retina" src="https://pigav.com/wp-content/themes/Newsmag/images/icons/ico-video-large.png" alt="pigAvVideoUrl"/></span></a></div>                            </div>

     <h3 class="entry-title td-module-title"><a href="https://pigav.com/215144/%e5%88%b6%e6%9c%8d%e4%b8%ad%e5%98%85c.html" rel="bookmark" title="制服中嘅C.">制服中嘅C.</a></h3>
     <div class="meta-info">
     </div>


     </div>


     </div> <!-- ./td-block-span4 -->

     <div class="td-block-span4">

     <div class="td_module_mx4 td_module_wrap td-animation-stack td-meta-info-hide">
     <div class="td-module-image">
     <div class="td-module-thumb"><a href="https://pigav.com/217255/vo-toi-da-bi-xuc-dong-boi-mot-hoc-sinh-khu-pho-minako-kirishima.html" rel="bookmark" title="Vợ tôi đã bị xúc động bởi một học sinh khu phố &#8230; Minako Kirishima"><img width="300" height="194" class="entry-thumb" src="https://img.pigav.com/2017/12/kkk018-300x194.jpg" srcset="https://img.pigav.com/2017/12/kkk018-300x194.jpg 300w, https://img.pigav.com/2017/12/kkk018-341x220.jpg 341w" sizes="(max-width: 300px) 100vw, 300px" alt="" title="Vợ tôi đã bị xúc động bởi một học sinh khu phố &#8230; Minako Kirishima"/></a></div>                            </div>

     <h3 class="entry-title td-module-title"><a href="https://pigav.com/217255/vo-toi-da-bi-xuc-dong-boi-mot-hoc-sinh-khu-pho-minako-kirishima.html" rel="bookmark" title="Vợ tôi đã bị xúc động bởi một học sinh khu phố &#8230; Minako Kirishima">Vợ tôi đã bị...</a></h3>
     <div class="meta-info">
     </div>


     </div>


     </div> <!-- ./td-block-span4 --></div><!--./row-fluid-->
     * td_block_id : td_uid_11_5a71ef839c8be
     * td_hide_prev : false
     * td_hide_next : false
     */

    private String td_data;
    private String td_block_id;
    private boolean td_hide_prev;
    private boolean td_hide_next;

    public String getTd_data() {
        return td_data;
    }

    public void setTd_data(String td_data) {
        this.td_data = td_data;
    }

    public String getTd_block_id() {
        return td_block_id;
    }

    public void setTd_block_id(String td_block_id) {
        this.td_block_id = td_block_id;
    }

    public boolean isTd_hide_prev() {
        return td_hide_prev;
    }

    public void setTd_hide_prev(boolean td_hide_prev) {
        this.td_hide_prev = td_hide_prev;
    }

    public boolean isTd_hide_next() {
        return td_hide_next;
    }

    public void setTd_hide_next(boolean td_hide_next) {
        this.td_hide_next = td_hide_next;
    }
}
