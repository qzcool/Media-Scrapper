package com.u91porn.ui.history;

/**
 * @author flymegoc
 * @date 2017/12/22
 */

public interface IHistory {
    void loadHistoryData(boolean pullToRefresh);
}
