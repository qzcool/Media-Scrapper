package com.u91porn.ui.porn91forum.browse91porn;

/**
 *
 * @author flymegoc
 * @date 2018/1/24
 */

public interface IBrowse91 {
    void loadContent(Long tid,boolean isNightModel);
}
