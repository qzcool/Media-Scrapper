package com.u91porn.exception;

/**
 * @author flymegoc
 * @date 2018/2/7
 */

public class MessageException extends Exception {
    public MessageException(String message) {
        super(message);
    }
}
