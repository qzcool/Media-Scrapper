package com.u91porn.ui.setting;

import com.qmuiteam.qmui.widget.grouplist.QMUICommonListItemView;

/**
 * @author flymegoc
 * @date 2018/2/6
 */

public interface ISetting {
    void test91PornVideo(String baseUrl, QMUICommonListItemView qmuiCommonListItemView, String key);

    void test91PornForum(String baseUrl, QMUICommonListItemView qmuiCommonListItemView, String key);

    void testPigAv(String baseUrl, QMUICommonListItemView qmuiCommonListItemView, String key);

    boolean isHaveUnFinishDownloadVideo();

    boolean isHaveFinishDownloadVideoFile();

    void moveOldDownloadVideoToNewDir(String newDirPath, QMUICommonListItemView qmuiCommonListItemView);
}
