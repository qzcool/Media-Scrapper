package com.u91porn.ui.splash;

import com.u91porn.ui.user.IBaseUser;

/**
 *
 * @author flymegoc
 * @date 2017/12/21
 */

public interface ISplash extends IBaseUser{
}
