package com.u91porn.ui.pigav;

/**
 * @author flymegoc
 * @date 2018/1/30
 */

public interface IPigAv {
    void videoList(String category, boolean pullToRefresh);

    void moreVideoList(String category, boolean pullToRefresh);
}
